-- Dump de la Base de Datos
-- Fecha: Wednesday 10 July 2013 - 10:00:33
--
-- Version: 1.1.1, del 18 de Marzo de 2012, insidephp@gmail.com
-- Soporte y Updaters: http://insidephp.sytes.net
--
-- Host: `localhost`    Database: `estadistica`
-- ------------------------------------------------------
-- Server version	5.5.31-0ubuntu0.12.04.2

--
-- Table structure for table `clases`
--

DROP TABLE IF EXISTS clases;
CREATE TABLE `clases` (
  `idclases` int(11) NOT NULL AUTO_INCREMENT,
  `li` int(11) DEFAULT NULL,
  `ls` int(11) DEFAULT NULL,
  `xi` float(11,2) DEFAULT NULL,
  `fa` int(11) DEFAULT NULL,
  `hi` float(11,2) DEFAULT NULL,
  `Fa_` int(11) DEFAULT NULL,
  `Ha` float(11,2) DEFAULT NULL,
  PRIMARY KEY (`idclases`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clases`
--

LOCK TABLES clases WRITE;
INSERT INTO clases VALUES('1', '12', '28', '20.00', '4', '0.44', '4', '0.44');
INSERT INTO clases VALUES('2', '29', '45', '37.00', '4', '0.44', '8', '0.89');
INSERT INTO clases VALUES('3', '46', '62', '54.00', '0', '0.00', '8', '0.89');
INSERT INTO clases VALUES('4', '63', '79', '71.00', '1', '0.11', '9', '1.00');
UNLOCK TABLES;


--
-- Table structure for table `datos`
--

DROP TABLE IF EXISTS datos;
CREATE TABLE `datos` (
  `iddatos` int(11) NOT NULL AUTO_INCREMENT,
  `dato` int(11) DEFAULT NULL,
  PRIMARY KEY (`iddatos`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datos`
--

LOCK TABLES datos WRITE;
UNLOCK TABLES;


--
-- Table structure for table `limites`
--

DROP TABLE IF EXISTS limites;
CREATE TABLE `limites` (
  `idlimites` int(11) NOT NULL AUTO_INCREMENT,
  `li` int(11) DEFAULT NULL,
  `ls` int(11) DEFAULT NULL,
  `fi` int(11) DEFAULT NULL,
  PRIMARY KEY (`idlimites`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `limites`
--

LOCK TABLES limites WRITE;
INSERT INTO limites VALUES('1', '0', '5', '6');
INSERT INTO limites VALUES('2', '5', '10', '3');
INSERT INTO limites VALUES('3', '10', '15', '12');
INSERT INTO limites VALUES('4', '15', '20', '6');
INSERT INTO limites VALUES('5', '20', '25', '3');
UNLOCK TABLES;


--
-- Table structure for table `reporte`
--

DROP TABLE IF EXISTS reporte;
CREATE TABLE `reporte` (
  `idreporte` int(11) NOT NULL AUTO_INCREMENT,
  `li` int(11) DEFAULT NULL,
  `ls` int(11) DEFAULT NULL,
  `xi` float(11,1) DEFAULT NULL,
  `fi` int(11) DEFAULT NULL,
  `fa` int(11) DEFAULT NULL,
  `xifi` float(11,1) DEFAULT NULL,
  `logxi` float(11,2) DEFAULT NULL,
  `logxifi` float(11,2) DEFAULT NULL,
  PRIMARY KEY (`idreporte`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reporte`
--

LOCK TABLES reporte WRITE;
INSERT INTO reporte VALUES('1', '0', '5', '2.5', '6', '6', '15.0', '0.40', '2.39');
INSERT INTO reporte VALUES('2', '5', '10', '7.5', '3', '9', '22.5', '0.88', '2.63');
INSERT INTO reporte VALUES('3', '10', '15', '12.5', '12', '21', '150.0', '1.10', '13.16');
INSERT INTO reporte VALUES('4', '15', '20', '17.5', '6', '27', '105.0', '1.24', '7.46');
INSERT INTO reporte VALUES('5', '20', '25', '22.5', '3', '30', '67.5', '1.35', '4.06');
UNLOCK TABLES;



-- Dump de la Base de Datos Completo.